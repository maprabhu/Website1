<?php
/**
 *  The template for displaying Sidebar.
 *
 *  @package lawyeria-lite
 */
?>
<aside id="sidebar-right">
	<?php dynamic_sidebar( 'right-sidebar' ); ?>
</aside><!--/aside #sidebar-right-->