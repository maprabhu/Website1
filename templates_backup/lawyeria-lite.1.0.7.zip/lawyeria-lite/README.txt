= Lawyeria Lite =

Contributors: codeinwp.com

Tags: black, blue, gray, white, light, one-column, responsive-layout, custom-background, custom-header, custom-menu, featured-images, sticky-post, threaded-comments, translation-ready

Requires at least:	3.3.0
Tested up to:		4.0

Lawyeria Lite

== Description ==
Lawyeria Lite is a free business WordPress Theme, super clean and fully responsive design. Coded with care in HTML5 &amp; CSS3, is easy to customize and well documented. Can be used to build a lawyer website, the homepage contact form along with the email/phone highly visible generate a great conversion rate.


= License =

Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License version 3.0.

The exceptions to this license are as follows: 

	* fancybox:
	
		License: www.fancyapps.com/fancybox/#license
		
	* jQuery Masonry v2.0.110517 beta
	
		Licensed under the MIT license.

	* Lato font

		http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL
		
	* Roboto Slab font
	
		http://www.apache.org/licenses/LICENSE-2.0.html