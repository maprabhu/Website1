

### 1.0.7 - 03/01/2015

 Changes: 


 * fixed customizer sanitization and remove screen_icon function deprecated
 * fixed rtl and removed header css
 * improved fonts loading


### 1.0.4 - 17/10/2014

 Changes: 


 * Version 1.0.1
 * Fixed 404 syntax error
 * Fixed title for logo
 * Fixed customizer syntax error
 * Update version to 1.0.2
 * Added rel=nofollow to footer link
 * Update version to 1.0.3
 * Fixed dropdown menu for large items
 * Up
