<!-- SINGLE PRACTICE AREA -->
<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'no-meta'); ?>
